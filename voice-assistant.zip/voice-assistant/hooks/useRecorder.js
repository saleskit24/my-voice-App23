import { useState, useEffect } from "react";

export function useRecorder() {
  const [isRecording, setIsRecording] = useState(false);
  const [mediaRecorder, setMediaRecorder] = useState(null);

  useEffect(() => {
    if (isRecording) {
      navigator.mediaDevices.getUserMedia({ audio: true }).then((stream) => {
        const recorder = new MediaRecorder(stream);
        setMediaRecorder(recorder);
        recorder.start();

        recorder.ondataavailable = (e) => {
          const audioBlob = new Blob([e.data], { type: 'audio/wav' });
          handleSend(audioBlob);
        };
      });
    } else {
      if (mediaRecorder) {
        mediaRecorder.stop();
      }
    }
  }, [isRecording]);

  const startRecording = () => {
    setIsRecording(true);
  };

  const stopRecording = () => {
    setIsRecording(false);
  };

  return [isRecording, startRecording, stopRecording];
}
