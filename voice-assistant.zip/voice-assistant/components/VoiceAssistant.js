import { useState } from "react";
import { Box, Button, Input, VStack, HStack } from "@chakra-ui/react";
import { useRecorder } from "../hooks/useRecorder";

export default function VoiceAssistant() {
  const [messages, setMessages] = useState([]);
  const [isRecording, startRecording, stopRecording] = useRecorder();

  const handleSend = async (audioBlob) => {
    const formData = new FormData();
    formData.append("audio", audioBlob);

    const response = await fetch("/api/whisper", {
      method: "POST",
      body: formData,
    });

    const data = await response.json();
    const text = data.text;

    setMessages((prev) => [...prev, { from: "user", text }]);

    const gptResponse = await fetch("/api/gpt", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ prompt: text }),
    });

    const gptData = await gptResponse.json();
    setMessages((prev) => [...prev, { from: "gpt", text: gptData.response }]);
  };

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };

  const handleSendFile = async () => {
    if (file) {
      const formData = new FormData();
      formData.append("file", file);

      const response = await fetch("/api/upload", {
        method: "POST",
        body: formData,
      });

      const data = await response.json();
      setMessages((prev) => [...prev, { from: "user", text: \`File uploaded: \${data.fileName}\` }]);
      setFile(null);
    }
  };

  return (
    <VStack spacing={4}>
      <Box>
        {messages.map((msg, idx) => (
          <HStack key={idx} align="start">
            <Box>{msg.from === "user" ? "You: " : "GPT: "}</Box>
            <Box>{msg.text}</Box>
          </HStack>
        ))}
      </Box>
      <HStack>
        <Button onClick={isRecording ? stopRecording : startRecording}>
          {isRecording ? "Stop" : "Record"}
        </Button>
        <Button onClick={handleSend}>Send</Button>
      </HStack>
      <HStack>
        <Input type="file" onChange={handleFileChange} />
        <Button onClick={handleSendFile}>Send File</Button>
      </HStack>
    </VStack>
  );
}
