import { whisperToText, textToSpeech } from "../../utils/whisper";

export default async function handler(req, res) {
  const { audio } = req.body;

  try {
    const text = await whisperToText(audio);
    res.status(200).json({ text });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
}
