import formidable from "formidable";
import fs from "fs";

export const config = {
  api: {
    bodyParser: false,
  },
};

export default async function handler(req, res) {
  const form = new formidable.IncomingForm();
  form.uploadDir = "./public/uploads";
  form.keepExtensions = true;

  form.parse(req, (err, fields, files) => {
    if (err) {
      res.status(500).json({ error: err.message });
      return;
    }

    const file = files.file;
    const fileName = file.newFilename;
    const filePath = `/uploads/${fileName}`;

    res.status(200).json({ fileName, filePath });
  });
}
